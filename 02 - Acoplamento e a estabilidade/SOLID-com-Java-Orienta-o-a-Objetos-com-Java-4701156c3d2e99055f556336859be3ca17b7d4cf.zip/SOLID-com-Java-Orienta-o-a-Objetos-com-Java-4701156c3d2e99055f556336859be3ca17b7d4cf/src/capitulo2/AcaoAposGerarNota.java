package capitulo2;

public interface AcaoAposGerarNota {
	void executa(NotaFiscal nf);
}
